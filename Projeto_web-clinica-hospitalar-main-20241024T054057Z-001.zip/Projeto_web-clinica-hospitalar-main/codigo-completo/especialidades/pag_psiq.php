<!DOCTYPE html>
<html lang="pt-bt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css especialidades/style_especial.css">
       <link rel="shortcut icon" href="./img/icon2.png">
    <title>AASH - Psiquiatria</title>
</head>
<body>
    <div class="header" id="header">
        <button onclick="toggleSidebar()" class="btn_iconheader">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-list" viewBox="0 0 16 16">
                <path fill-rule="evenodd" d="M2.5 12a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5z"/>
              </svg>
        </button>
        <div class="logo_aash">
            <img src="./img/icon2.png" alt="LOGO AASH" id="logoheader">
        </div>
        <div class="navegador_header" id="navegador_header">
            <button onclick="toggleSidebar()" class="btn_iconheader">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-unindent" viewBox="0 0 16 16">
                    <path fill-rule="evenodd" d="M13 8a.5.5 0 0 0-.5-.5H5.707l2.147-2.146a.5.5 0 1 0-.708-.708l-3 3a.5.5 0 0 0 0 .708l3 3a.5.5 0 0 0 .708-.708L5.707 8.5H12.5A.5.5 0 0 0 13 8Z"/>
                    <path fill-rule="evenodd" d="M3.5 4a.5.5 0 0 0-.5.5v7a.5.5 0 0 0 1 0v-7a.5.5 0 0 0-.5-.5Z"/>
                  </svg>
            </button>
             <a href="../tela-ini.php">Inicio</a>
            <a href="../marcar-consultas.php">Consulta</a>
            <a href="../fica-medica.php">Ficha Médica</a>
            <a href="../perfil.php">Perfil</a>
        </div>
    </div>
   
    </div>
    <script src="./js/tela-ini-java.js"></script>
     <div id="banner">                       
                <a href="#"><img src="./img/pisciquiatriaGRANDE.png"></a>
            </div>
    <div id="descricao">
    
    
    <h1>Qual a área de atuação da Psiquiatria?</h1>
    <div class="container">
     <img src="./img/psiqui1.jpg" alt="psiqui">
    <p>A atuação da psiquiatria é a atenção voltada para o bem-estar psicológico dos pacientes. Muitas vezes, a saúde mental está diretamente relacionada à qualidade de vida de uma pessoa. A psiquiatria oferece suporte emocional, promove a conscientização dos pacientes sobre suas próprias condições e auxilia no manejo das dificuldades cotidianas.

Além disso, a intervenção psiquiátrica também pode prevenir complicações e agravamentos dos transtornos mentais. A abordagem terapêutica precoce pode ajudar a minimizar as consequências negativas em diferentes áreas da vida, como relacionamentos pessoais, desempenho acadêmico e profissional, e saúde física.

No tratamento de transtornos mentais, a psiquiatria utiliza diversas estratégias, dentre elas, a psicoterapia e o uso de medicamentos psicotrópicos. A terapia visa promover a compreensão do problema do paciente, identificar padrões disfuncionais de pensamento e comportamento, além de desenvolver habilidades adaptativas para lidar com dificuldades emocionais.

Em relação aos medicamentos, eles podem ser prescritos com base no diagnóstico do paciente. Dessa forma, é possível controlar sintomas específicos e proporcionar ao indivíduo a oportunidade de vivenciar uma melhora significativa em sua saúde mental.

A psiquiatria também contribui de forma essencial para a desmistificação e redução do estigma relacionado aos transtornos mentais. Ao promover conhecimento e compreensão sobre essas condições, a especialidade médica busca combater preconceitos e oferecer suporte para que as pessoas tenham uma vida plena, mesmo com suas particularidades psicológicas.
    </div>
</p>
     <br>
     <h1>Qual a importância da Psiquiatria?</h1>
     <div class="container">
     <img src="./img/psiqui2.jpg" alt="psiqui">
     <p>A importância da psiquiatria na área da medicina é inegável. Essa especialidade médica dedica-se ao estudo, diagnóstico, tratamento e prevenção dos transtornos mentais. Sua abordagem multifacetada é fundamental para que os pacientes possam ter uma vida saudável e equilibrada.
        A psiquiatria é uma ciência que busca compreender e tratar os aspectos emocionais, cognitivos, comportamentais e sociais do indivíduo. Ela lida com uma ampla variedade de condições psíquicas, desde transtornos depressivos e de ansiedade até esquizofrenia e transtornos de personalidade.

Um dos principais objetivos da psiquiatria é diagnosticar adequadamente os transtornos mentais. Isso é essencial para que o tratamento seja direcionado corretamente e ofereça resultados eficazes. O diagnóstico preciso pode levar a uma melhor compreensão dos sintomas e à aplicação dos tratamentos apropriados, sejam eles medicamentosos, terapêuticos ou uma combinação de ambos.
    </div>
    </p>
    <br>
    <h1>Quais doenças podem ser previnidas na consulta ao Psiquiatra?</h1>

     <div id="btn-SI">
                <button class="marcar-consulta"><a href="https://aash.bio/tela-ini.php">Clique aqui para voltar!</a></button>
            </div>

</div>
</body>
</html>