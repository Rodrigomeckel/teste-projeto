<!DOCTYPE html>
<html lang="pt-bt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css especialidades/style_especial.css">
       <link rel="shortcut icon" href="./img/icon2.png">
    <title>AASH - Ortopedia</title>
</head>
<body>
    <div class="header" id="header">
        <button onclick="toggleSidebar()" class="btn_iconheader">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-list" viewBox="0 0 16 16">
                <path fill-rule="evenodd" d="M2.5 12a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4a.5.5 0 0 1 .5-.5h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5z"/>
              </svg>
        </button>
        <div class="logo_aash">
            <img src="./img/icon2.png" alt="LOGO AASH" id="logoheader">
        </div>
        <div class="navegador_header" id="navegador_header">
            <button onclick="toggleSidebar()" class="btn_iconheader">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-unindent" viewBox="0 0 16 16">
                    <path fill-rule="evenodd" d="M13 8a.5.5 0 0 0-.5-.5H5.707l2.147-2.146a.5.5 0 1 0-.708-.708l-3 3a.5.5 0 0 0 0 .708l3 3a.5.5 0 0 0 .708-.708L5.707 8.5H12.5A.5.5 0 0 0 13 8Z"/>
                    <path fill-rule="evenodd" d="M3.5 4a.5.5 0 0 0-.5.5v7a.5.5 0 0 0 1 0v-7a.5.5 0 0 0-.5-.5Z"/>
                  </svg>
            </button>
            <a href="../tela-ini.php">Inicio</a>
            <a href="../marcar-consultas.php">Consulta</a>
            <a href="../fica-medica.php">Ficha Médica</a>
            <a href="../perfil.php">Perfil</a>
        </div>
    </div>
   
    </div>
    <script src="./js/tela-ini-java.js"></script>
     <div id="banner">                       
                <a href="#"><img src="./img/ortopediaGRANDE.png"></a>
            </div>
    <div id="descricao">
    
    
    <h1>Qual a área de atuação da Ortopedia?</h1>
    <div class="container">
     <img src="./img/orto1.jpg" alt="orto">
    <p>A Ortopedia é uma especialidade médica que trata de doenças e lesões relacionadas ao sistema musculoesquelético, ou seja, ossos, músculos, articulações, ligamentos e tendões. É uma área crucial que desempenha um papel fundamental no diagnóstico, tratamento e reabilitação de problemas ortopédicos, permitindo que as pessoas mantenham a qualidade de vida.

A ortopedia engloba uma vasta gama de condições que afetam pessoas de todas as idades, desde crianças até idosos. Lesões traumáticas, como fraturas ósseas, luxações e distensões musculares, bem como doenças crônicas como a osteoporose, são tratadas pela especialidade. Além disso, a Ortopedia também está envolvida em intervenções cirúrgicas para correção de deformidades congênitas, como a escoliose, ou correção de lesões após acidentes graves.
</p>
</div>
     <br>
     <h1>Qual a importância da Ortopedia?</h1>
     <div class="container">
     <img src="./img/orto2.jpg" alt="orto">
     <p>Uma das principais razões pelas quais a Ortopedia é importante é porque os ossos e articulações são responsáveis por fornecer apoio estrutural ao corpo humano. A capacidade de caminhar, mover-se, levantar objetos e realizar as atividades diárias depende da saúde óssea e articular adequada. Portanto, o tratamento de condições ortopédicas é essencial para permitir que as pessoas mantenham sua mobilidade e independência.

Outro ponto crucial é que a Ortopedia contribui para a recuperação e reabilitação de lesões musculoesqueléticas. Os médicos ortopedistas são treinados para realizar procedimentos cirúrgicos de reparação e reconstrução, bem como para prescrever terapias de reabilitação física, como exercícios e fisioterapia. Essas intervenções ajudam os pacientes a recuperarem sua força, função e mobilidade após uma lesão ou cirurgia.

Além disso, a Ortopedia desempenha um papel importante no tratamento de doenças ortopédicas em crianças em fase de crescimento. O diagnóstico precoce e o tratamento adequado podem evitar complicações futuras, como deformidades ósseas e dificuldades na locomoção. Os médicos ortopedistas pediátricos são especializados em cuidar de problemas ortopédicos específicos em crianças, como o pé torto congênito. </p>
    </div>
   
    <br>
    <h1>Quais doenças podem ser previnidas na consulta ao Ortopedista?</h1>

  <div id="btn-SI">
                <button class="marcar-consulta"><a href="https://aash.bio/tela-ini.php">Clique aqui para voltar!</a></button>
            </div>

</div>
</body>
</html>